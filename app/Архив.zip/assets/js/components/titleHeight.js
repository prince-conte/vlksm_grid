
$(function() {



    setTimeout(function(){
        $('.js-item-title').equalHeights();

        $('.js-item-title-big').equalHeights();

        $('.js-item-title-max').equalHeights();
    }, 1000)
});